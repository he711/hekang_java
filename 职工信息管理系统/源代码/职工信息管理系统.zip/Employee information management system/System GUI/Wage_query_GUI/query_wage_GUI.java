package Wage_query_GUI;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.sql.SQLException;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import Wage_query_backend.show_wage_all_get;
import Wage_query_backend.show_wage_all_set;

//�����ʲ�ѯ���Ĵ���
public class query_wage_GUI extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private String head[] = null;
	private Object[][] data = null;
	private show_wage_all_set user = new show_wage_all_set();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					query_wage_GUI frame = new query_wage_GUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * 
	 * @throws SQLException
	 */
	public query_wage_GUI() throws SQLException {
		setResizable(false);

		setTitle("��ʾ���й�����" + user.min + "��" + user.max + "֮����������Ϣ");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1200, 600);
		Dimension us = this.getSize();
		Dimension them = Toolkit.getDefaultToolkit().getScreenSize();

		int x = (them.width - us.width) / 2;
		int y = (them.height - us.height) / 2;

		this.setLocation(x, y);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 700, 250);

		table = new JTable();
		DefaultTableCellRenderer tcr = new DefaultTableCellRenderer();// ��Ԫ����Ⱦ��
		tcr.setHorizontalAlignment(JLabel.CENTER);
		table.setDefaultRenderer(Object.class, tcr);// ������Ⱦ��
		table.setRowHeight(25);
		table.setBorder(new LineBorder(new Color(0, 0, 0)));
		head = new String[] { "ְ����", "����", "�Ա�", "����", "ѧ��", "����", "סַ", "�绰", "��ְ����", "״̬" };

		DefaultTableModel tableModel = new DefaultTableModel(queryData(), head) {
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table.setModel(tableModel);

		scrollPane.setViewportView(table);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addComponent(scrollPane,
				GroupLayout.DEFAULT_SIZE, 684, Short.MAX_VALUE));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 550, GroupLayout.PREFERRED_SIZE)
						.addGap(66)));
		// ��ͷ��С
		table.getColumnModel().getColumn(0).setPreferredWidth(30);
		table.getColumnModel().getColumn(1).setPreferredWidth(30);
		table.getColumnModel().getColumn(2).setPreferredWidth(10);
		table.getColumnModel().getColumn(3).setPreferredWidth(10);
		table.getColumnModel().getColumn(4).setPreferredWidth(20);
		table.getColumnModel().getColumn(5).setPreferredWidth(20);
		table.getColumnModel().getColumn(6).setPreferredWidth(200);
		table.getColumnModel().getColumn(7).setPreferredWidth(90);
		table.getColumnModel().getColumn(8).setPreferredWidth(60);
		table.getColumnModel().getColumn(9).setPreferredWidth(200);

		contentPane.setLayout(gl_contentPane);

	}

	// ���ɱ�������
	/**
	 * @return
	 * @throws SQLException
	 */
	public Object[][] queryData() throws SQLException {
		List<show_wage_all_get> list = user.show_all();
		data = new Object[list.size()][head.length];

		for (int i = 0; i < list.size(); i++) {
			for (int j = 0; j < head.length; j++) {
				// ְ����
				data[i][0] = list.get(i).getwon();

				// ����
				data[i][1] = list.get(i).getname();

				// �Ա�
				data[i][2] = list.get(i).getsex();

				// ����
				data[i][3] = list.get(i).getage();

				// ѧ��
				data[i][4] = list.get(i).geteducation();

				// ����
				data[i][5] = list.get(i).getsalary();

				// סַ
				data[i][6] = list.get(i).getaddress();

				// �绰
				data[i][7] = list.get(i).getphone();

				// ��ְ����
				data[i][8] = list.get(i).gethiredate();

				// ״̬
				data[i][9] = list.get(i).getworking_condition();
			}
		}
		return data;
	}

}
