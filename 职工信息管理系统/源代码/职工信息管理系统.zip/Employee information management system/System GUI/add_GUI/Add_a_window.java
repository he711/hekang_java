package add_GUI;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import add_backend.add_the_worker;

//������ְ��
public class Add_a_window extends JFrame {

	private JPanel contentPane;
	private JTextField textField_name; // ����
	private JTextField textField_age; // ����
	private JTextField textField_sex; // �Ա�
	private JTextField textField_salary; // ����
	private JTextField textField_working_condition; // ״̬
	private JTextField textField_address; // סַ
	private JTextField textField_phone; // �绰
	String education;
	String sex;
	add_the_worker add = new add_the_worker();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_a_window frame = new Add_a_window();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * ����
	 * 
	 * @throws SQLException
	 */
	public Add_a_window() throws SQLException {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();

		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		// ���Ӱ�ť
		JButton btnNewButton = new JButton("����");
		btnNewButton.setFont(new Font("����", Font.PLAIN, 14));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// ��������
				add.name = textField_name.getText();

				// �����Ա�
				add.sex = sex;

				// ���ַ���ת�����������ӵ�����
				add.age = textField_age.getText();

				// ����ѧ��
				add.education = education;

				// ���ӹ���
				add.salary = textField_salary.getText();

				// ����סַ
				add.address = textField_address.getText();

				// ���ӵ绰
				add.phone = textField_phone.getText();

				// ����״̬
				add.working_condition = textField_working_condition.getText();

				try {
					//// ���Ӳ���
					add.add_the();
					JOptionPane.showMessageDialog(contentPane, "���ӳɹ���", "�ɹ�", JOptionPane.WARNING_MESSAGE);
					// �رյ�ǰ���ڣ����ӿ�
					dispose();

				} catch (SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					JOptionPane.showMessageDialog(contentPane, "����ʧ�ܣ�", "����", JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton.setBounds(307, 366, 97, 32);
		contentPane.add(btnNewButton);

		// ְ�����ı�

		JLabel lblNewLabel = new JLabel("ְ���ţ�");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel.setBounds(333, 59, 99, 32);
		contentPane.add(lblNewLabel);

		// ְ�������ı�
		add.getwon();
		String won = String.valueOf(add.won);
		JLabel lblNewLabel_1 = new JLabel(won);
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(442, 61, 84, 28);
		contentPane.add(lblNewLabel_1);

		// ȡ��
		JButton btnNewButton_1 = new JButton("ȡ��");
		btnNewButton_1.setFont(new Font("����", Font.PLAIN, 14));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton_1.setBounds(540, 366, 97, 32);
		contentPane.add(btnNewButton_1);

		// ����
		JLabel lblNewLabel_2 = new JLabel("����:");
		lblNewLabel_2.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2.setBounds(117, 141, 58, 23);
		contentPane.add(lblNewLabel_2);

		// �����ı���
		textField_name = new JTextField();
		textField_name.setBounds(185, 142, 119, 23);
		contentPane.add(textField_name);
		textField_name.setColumns(10);

		// ѧ��
		JLabel lblNewLabel_2_1 = new JLabel("ѧ��:");
		lblNewLabel_2_1.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2_1.setBounds(333, 141, 58, 23);
		contentPane.add(lblNewLabel_2_1);

		// ѧ�������˵�
		JPanel panel = new JPanel();
		panel.setBounds(401, 141, 119, 32);
		contentPane.add(panel);
		panel.setLayout(null);

		JComboBox<String> comboBox = new JComboBox<String>();
		comboBox.addItem("�о���");
		comboBox.addItem("����");
		comboBox.addItem("ר��");
		comboBox.addItem("��ר");
		comboBox.addItem("����");
		comboBox.addItem("����");
		comboBox.addItem("Сѧ");
		comboBox.addItem("����");
		comboBox.setBounds(0, 0, 119, 23);
		panel.add(comboBox);
		// Ĭ�ϵ�ѧ��
		comboBox.setSelectedIndex(0);
		education = "�о���";
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// ��ȡ������ѡ��
				education = comboBox.getSelectedItem().toString();
			}
		});

		// �Ա�
		JLabel lblNewLabel_2_2 = new JLabel("�Ա�:");
		lblNewLabel_2_2.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2_2.setBounds(117, 217, 58, 23);
		contentPane.add(lblNewLabel_2_2);

		// �Ա������˵�
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBounds(185, 217, 119, 32);
		contentPane.add(panel_1);

		JComboBox<String> comboBox_1 = new JComboBox<String>();
		comboBox_1.addItem("��");
		comboBox_1.addItem("Ů");
		comboBox_1.setBounds(0, 0, 119, 23);
		panel_1.add(comboBox_1);
		// Ĭ�ϵ�ѧ��
		comboBox_1.setSelectedIndex(0);
		sex = "��";
		comboBox_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// ��ȡ������ѡ��
				sex = comboBox_1.getSelectedItem().toString();
			}
		});

		// ����
		JLabel lblNewLabel_2_3 = new JLabel("����:");
		lblNewLabel_2_3.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2_3.setBounds(117, 297, 58, 23);
		contentPane.add(lblNewLabel_2_3);

		// �����ı���
		textField_age = new JTextField();
		textField_age.setColumns(10);
		textField_age.setBounds(185, 298, 119, 23);
		contentPane.add(textField_age);

		// ״̬
		JLabel lblNewLabel_2_1_1 = new JLabel("״̬:");
		lblNewLabel_2_1_1.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2_1_1.setBounds(333, 297, 58, 23);
		contentPane.add(lblNewLabel_2_1_1);

		// ״̬�ı���
		textField_working_condition = new JTextField();
		textField_working_condition.setColumns(10);
		textField_working_condition.setBounds(401, 298, 409, 23);
		contentPane.add(textField_working_condition);

		// ����
		JLabel lblNewLabel_2_1_2 = new JLabel("����:");
		lblNewLabel_2_1_2.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2_1_2.setBounds(333, 217, 58, 23);
		contentPane.add(lblNewLabel_2_1_2);

		// �����ı���
		textField_salary = new JTextField();
		textField_salary.setColumns(10);
		textField_salary.setBounds(401, 218, 119, 23);
		contentPane.add(textField_salary);

		// �绰
		JLabel lblNewLabel_2_1_3 = new JLabel("�绰:");
		lblNewLabel_2_1_3.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2_1_3.setBounds(557, 141, 58, 23);
		contentPane.add(lblNewLabel_2_1_3);

		// �绰�ı���
		textField_phone = new JTextField();
		textField_phone.setColumns(10);
		textField_phone.setBounds(625, 142, 185, 23);
		contentPane.add(textField_phone);

		// סַ
		JLabel lblNewLabel_2_1_3_1 = new JLabel("סַ:");
		lblNewLabel_2_1_3_1.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2_1_3_1.setBounds(557, 217, 58, 23);
		contentPane.add(lblNewLabel_2_1_3_1);

		// סַ�ı���
		textField_address = new JTextField();
		textField_address.setColumns(10);
		textField_address.setBounds(625, 218, 185, 23);
		contentPane.add(textField_address);

		// ��ְʱ��
		JLabel lblNewLabel_2_4 = new JLabel("��ְ����:");
		lblNewLabel_2_4.setFont(new Font("����", Font.PLAIN, 15));
		lblNewLabel_2_4.setBounds(599, 461, 84, 23);
		contentPane.add(lblNewLabel_2_4);

		// ��ǰʱ��
		add.gethiredate();
		JLabel lblNewLabel_2_5 = new JLabel(add.hiredate);
		lblNewLabel_2_5.setFont(new Font("����", Font.PLAIN, 15));
		lblNewLabel_2_5.setBounds(697, 461, 113, 23);
		contentPane.add(lblNewLabel_2_5);
	}

}
