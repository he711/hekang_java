package main_interface_GUI;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import In_the_query_GUI.In_the_query_GUI;
import In_the_query_backend.show_education_all_set;
import Wage_query_GUI.query_wage_GUI;
import Wage_query_backend.show_wage_all_set;
import add_GUI.Add_a_window;
import main_interface_backend_Query_the_worker.Query_the_worker;
import main_interface_backend_Query_the_worker.show_all;
import main_interface_backend_Query_the_worker.show_all_employees;
import main_interface_backend_data_analysis.JTextFieldHintListener;
import main_interface_backend_data_analysis.The_average_length_of_service;
import main_interface_backend_data_analysis.age_distribution;
import main_interface_backend_data_analysis.average_age;
import main_interface_backend_data_analysis.average_wage;
import main_interface_backend_data_analysis.cultural_distribution;

public class MainWindow extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private show_all_employees user = new show_all_employees();
	Object[][] textadminObjects = null;
	private JTable table_2;
	Timer timer = new Timer(); // ʱ���������������ˢ�£�

	// ������ѯ
	public Query_the_worker query_the_worker = new Query_the_worker();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainWindow frame = new MainWindow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainWindow() {
		setTitle("��ҳ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1200, 700);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		// ���Ļ��̶�ְ�������ķֲ����
		JLabel lblNewLabel = new JLabel(
				"\u5404\u6587\u5316\u7A0B\u5EA6\u804C\u5DE5\u4EBA\u6570\u7684\u5206\u5E03\u60C5\u51B5");
		lblNewLabel.setBounds(10, 10, 250, 20);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 15));
		contentPane.add(lblNewLabel);

		// �о���
		JLabel lblNewLabel_1 = new JLabel("\u7814\u7A76\u751F:");
		lblNewLabel_1.setBounds(10, 38, 58, 15);
		lblNewLabel_1.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1);

		// ����
		JLabel lblNewLabel_1_1 = new JLabel("\u672C\u79D1:");
		lblNewLabel_1_1.setBounds(10, 55, 44, 15);
		lblNewLabel_1_1.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1);

		// ר��
		JLabel lblNewLabel_1_1_1 = new JLabel("\u4E13\u79D1:");
		lblNewLabel_1_1_1.setBounds(10, 72, 44, 15);
		lblNewLabel_1_1_1.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1);

		// ��ר
		JLabel lblNewLabel_1_1_1_1 = new JLabel("\u4E2D\u4E13:");
		lblNewLabel_1_1_1_1.setBounds(10, 89, 44, 15);
		lblNewLabel_1_1_1_1.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_1);

		// ����
		JLabel lblNewLabel_1_1_1_2 = new JLabel("\u9AD8\u4E2D:");
		lblNewLabel_1_1_1_2.setBounds(10, 106, 44, 15);
		lblNewLabel_1_1_1_2.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_2);

		// ����
		JLabel lblNewLabel_1_1_1_3 = new JLabel("\u521D\u4E2D:");
		lblNewLabel_1_1_1_3.setBounds(10, 123, 44, 15);
		lblNewLabel_1_1_1_3.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_3);

		// Сѧ
		JLabel lblNewLabel_1_1_1_4 = new JLabel("\u5C0F\u5B66:");
		lblNewLabel_1_1_1_4.setBounds(10, 140, 44, 15);
		lblNewLabel_1_1_1_4.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_4);

		// ��ȡѧ��ͳ��
		cultural_distribution cultural = new cultural_distribution();
		try {
			cultural.cultural_distribution_get();
		} catch (SQLException e3) {
			// TODO �Զ����ɵ� catch ��
			e3.printStackTrace();
		}

		// �о�������
		JLabel lblNewLabel_1_1_1_5 = new JLabel(Integer.toString(cultural.education_count[0]));
		lblNewLabel_1_1_1_5.setBounds(63, 38, 29, 15);
		lblNewLabel_1_1_1_5.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_5);

		// ��������
		JLabel lblNewLabel_1_1_1_5_1 = new JLabel(Integer.toString(cultural.education_count[1]));
		lblNewLabel_1_1_1_5_1.setBounds(63, 55, 29, 15);
		lblNewLabel_1_1_1_5_1.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_5_1);

		// ר������
		JLabel lblNewLabel_1_1_1_5_2 = new JLabel(Integer.toString(cultural.education_count[2]));
		lblNewLabel_1_1_1_5_2.setBounds(63, 72, 29, 15);
		lblNewLabel_1_1_1_5_2.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_5_2);

		// ��ר����
		JLabel lblNewLabel_1_1_1_5_3 = new JLabel(Integer.toString(cultural.education_count[3]));
		lblNewLabel_1_1_1_5_3.setBounds(63, 89, 29, 15);
		lblNewLabel_1_1_1_5_3.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_5_3);

		// ��������
		JLabel lblNewLabel_1_1_1_5_4 = new JLabel(Integer.toString(cultural.education_count[4]));
		lblNewLabel_1_1_1_5_4.setBounds(63, 106, 29, 15);
		lblNewLabel_1_1_1_5_4.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_5_4);

		// ��������
		JLabel lblNewLabel_1_1_1_5_5 = new JLabel(Integer.toString(cultural.education_count[5]));
		lblNewLabel_1_1_1_5_5.setBounds(63, 123, 29, 15);
		lblNewLabel_1_1_1_5_5.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_5_5);

		// Сѧ����
		JLabel lblNewLabel_1_1_1_5_6 = new JLabel(Integer.toString(cultural.education_count[6]));
		lblNewLabel_1_1_1_5_6.setBounds(63, 140, 29, 15);
		lblNewLabel_1_1_1_5_6.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_5_6);

		// �������ְ�������ķֲ����
		JLabel lblNewLabel_2 = new JLabel(
				"\u5404\u5E74\u9F84\u6BB5\u804C\u5DE5\u4EBA\u6570\u7684\u5206\u5E03\u60C5\u51B5");
		lblNewLabel_2.setBounds(10, 165, 250, 26);
		lblNewLabel_2.setFont(new Font("����", Font.BOLD, 15));
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_1_2 = new JLabel("18-20:");
		lblNewLabel_1_2.setBounds(10, 193, 58, 15);
		lblNewLabel_1_2.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_2);

		JLabel lblNewLabel_1_1_2 = new JLabel("21-30:");
		lblNewLabel_1_1_2.setBounds(10, 210, 44, 15);
		lblNewLabel_1_1_2.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_2);

		JLabel lblNewLabel_1_1_1_6 = new JLabel("31-40:");
		lblNewLabel_1_1_1_6.setBounds(10, 227, 44, 15);
		lblNewLabel_1_1_1_6.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_6);

		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("41-50:");
		lblNewLabel_1_1_1_1_1.setBounds(10, 244, 44, 15);
		lblNewLabel_1_1_1_1_1.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_1_1);

		// 50-60
		JLabel lblNewLabel_1_1_1_2_1 = new JLabel("51-60:");
		lblNewLabel_1_1_1_2_1.setBounds(10, 261, 44, 15);
		lblNewLabel_1_1_1_2_1.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_2_1);

		// ����λ�ȡ
		age_distribution agedistribution = new age_distribution();
		try {
			agedistribution.age_distribution_get();
		} catch (SQLException e3) {
			// TODO �Զ����ɵ� catch ��
			e3.printStackTrace();
		}

		// 10-20������
		JLabel lblNewLabel_1_1_1_5_7 = new JLabel(Integer.toString(agedistribution.age_distribution_show[0]));
		lblNewLabel_1_1_1_5_7.setBounds(63, 193, 29, 15);
		lblNewLabel_1_1_1_5_7.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_5_7);

		// 20-30������
		JLabel lblNewLabel_1_1_1_5_1_1 = new JLabel(Integer.toString(agedistribution.age_distribution_show[1]));
		lblNewLabel_1_1_1_5_1_1.setBounds(63, 210, 29, 15);
		lblNewLabel_1_1_1_5_1_1.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_5_1_1);

		// 30-40������
		JLabel lblNewLabel_1_1_1_5_2_1 = new JLabel(Integer.toString(agedistribution.age_distribution_show[2]));
		lblNewLabel_1_1_1_5_2_1.setBounds(63, 227, 29, 15);
		lblNewLabel_1_1_1_5_2_1.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_5_2_1);

		// 40-50������
		JLabel lblNewLabel_1_1_1_5_3_1 = new JLabel(Integer.toString(agedistribution.age_distribution_show[3]));
		lblNewLabel_1_1_1_5_3_1.setBounds(63, 244, 29, 15);
		lblNewLabel_1_1_1_5_3_1.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_5_3_1);

		// 50-60������
		JLabel lblNewLabel_1_1_1_5_4_1 = new JLabel(Integer.toString(agedistribution.age_distribution_show[4]));
		lblNewLabel_1_1_1_5_4_1.setBounds(63, 261, 29, 15);
		lblNewLabel_1_1_1_5_4_1.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_5_4_1);

		// ƽ������
		JLabel lblNewLabel_1_3 = new JLabel("\u5E73\u5747\u5E74\u9F84:");
		lblNewLabel_1_3.setBounds(10, 286, 71, 15);
		lblNewLabel_1_3.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_3);

		// ƽ����������
		average_age average = new average_age();
		try {
			average.average_age_get();
		} catch (SQLException e2) {
			// TODO �Զ����ɵ� catch ��
			e2.printStackTrace();
		}

		// ƽ����������
		JLabel lblNewLabel_1_1_1_5_8 = new JLabel(Integer.toString(average.average_age_show));
		lblNewLabel_1_1_1_5_8.setBounds(73, 286, 29, 15);
		lblNewLabel_1_1_1_5_8.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_5_8);

		// ƽ������
		JLabel lblNewLabel_1_3_1 = new JLabel("\u5E73\u5747\u5DE5\u9F84:");
		lblNewLabel_1_3_1.setBounds(10, 311, 71, 15);
		lblNewLabel_1_3_1.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_3_1);

		// ƽ������
		The_average_length_of_service average_length = new The_average_length_of_service();
		try {
			average_length.The_average_length_of_service_get();
		} catch (SQLException e2) {
			// TODO �Զ����ɵ� catch ��
			e2.printStackTrace();
		}

		// ƽ����������
		JLabel lblNewLabel_1_1_1_5_8_1 = new JLabel(
				Integer.toString(average_length.The_average_length_of_service_show));
		lblNewLabel_1_1_1_5_8_1.setBounds(73, 311, 29, 15);
		lblNewLabel_1_1_1_5_8_1.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_5_8_1);

		// ƽ������
		JLabel lblNewLabel_1_3_2 = new JLabel("\u5E73\u5747\u5DE5\u8D44:");
		lblNewLabel_1_3_2.setBounds(10, 336, 71, 15);
		lblNewLabel_1_3_2.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_3_2);

		// ƽ��������
		average_wage wage = new average_wage();
		try {
			wage.average_wage_get();
		} catch (SQLException e2) {
			// TODO �Զ����ɵ� catch ��
			e2.printStackTrace();
		}

		// ƽ��������
		JLabel lblNewLabel_1_1_1_5_2_2 = new JLabel(Integer.toString(wage.average_wage_show));
		lblNewLabel_1_1_1_5_2_2.setBounds(73, 336, 44, 15);
		lblNewLabel_1_1_1_5_2_2.setFont(new Font("����", Font.BOLD, 13));
		contentPane.add(lblNewLabel_1_1_1_5_2_2);

		// ������ְ����ť
		JButton btnNewButton = new JButton("\u6DFB\u52A0\u65B0\u804C\u5DE5");
//		btnNewButton.setBackground(Color.YELLOW);
		btnNewButton.setBounds(70, 560, 150, 50);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Add_a_window a_window = new Add_a_window();
					Add_a_window.main(null);
				} catch (SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
			}
		});
		contentPane.add(btnNewButton);

		// ְ����Ϣ��ѯ
		JLabel lblNewLabel_51 = new JLabel("ְ����Ϣ��Χ����");
		lblNewLabel_51.setBounds(10, 370, 250, 20);
		lblNewLabel_51.setFont(new Font("����", Font.BOLD, 15));
		contentPane.add(lblNewLabel_51);
		// ������ѧ����ѯ�ı�
		JLabel lblNewLabel_3 = new JLabel("��ѧ������:");
		lblNewLabel_3.setBounds(10, 500, 92, 21);
		contentPane.add(lblNewLabel_3);

		// ��ѯѧ����ť
		JButton btnNewButton_3 = new JButton("\u67E5\u8BE2");
		btnNewButton_3.setBounds(207, 500, 60, 21);

		// ��ѯѧ���ı���
		textField = new JTextField();
		textField.setBounds(92, 500, 100, 21);
		contentPane.add(textField);
		textField.setColumns(10);
//		btnNewButton_3.setBackground(Color.YELLOW);
		// ���ѧ������
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// �ж��Ƿ�����Ϊ��
				if (textField.getText() == null || textField.getText().length() <= 0) {
					textField.setText(null);
					JOptionPane.showMessageDialog(contentPane, "�������ѯ��", "����", JOptionPane.WARNING_MESSAGE);
				} else {
					String textString = textField.getText();
					if (textString.equals("�о���") == true || textString.equals("����") == true
							|| textString.equals("ר��") == true || textString.equals("��ר") == true
							|| textString.equals("����") == true || textString.equals("����") == true
							|| textString.equals("Сѧ") == true || textString.equals("����") == true) {
						show_education_all_set education_set = new show_education_all_set();
						education_set.education = textString;
						In_the_query_GUI.main(null);

						// �������
						textField.setText(null);
					} else {
						JOptionPane.showMessageDialog(contentPane, "û�д�ѧ��!��", "����", JOptionPane.WARNING_MESSAGE);
					}

				}
			}
		});
		contentPane.add(btnNewButton_3);

		// �����빤�ʲ�ѯ�ı�
		JLabel lblNewLabel_3_1 = new JLabel("����������:");
		lblNewLabel_3_1.setBounds(10, 430, 100, 21);
		contentPane.add(lblNewLabel_3_1);

		// ��ѯ�����ı���1
		textField_1 = new JTextField();
		textField_1.setBounds(92, 406, 100, 21);
		textField_1.setColumns(10);
		contentPane.add(textField_1);

		// ��
		JLabel lblNewLabel_4 = new JLabel("��");
		lblNewLabel_4.setBounds(133, 434, 29, 15);
		lblNewLabel_4.setFont(new Font("����", Font.PLAIN, 14));
		contentPane.add(lblNewLabel_4);

		// ��ѯ�����ı���2
		textField_2 = new JTextField();
		textField_2.setBounds(92, 452, 100, 21);
		textField_2.setColumns(10);
		contentPane.add(textField_2);

		// ��ѯ���ʰ�ť
		JButton btnNewButton_3_1 = new JButton("\u67E5\u8BE2");
		btnNewButton_3_1.setBounds(207, 429, 60, 21);
//		btnNewButton_3_1.setBackground(Color.YELLOW);
		// ��ָ����Χ�Ĺ�������
		btnNewButton_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Float.parseFloat(textField_1.getText());
					Float.parseFloat(textField_2.getText());
					// �ж��Ƿ�����Ϊ��
					if (textField_1.getText() == null
							|| textField_1.getText().length() <= 0 && textField_2.getText() == null
							|| textField_2.getText().length() <= 0) {
						JOptionPane.showMessageDialog(contentPane, "�������ѯ��", "����", JOptionPane.WARNING_MESSAGE);
						// �������
					} else if (Integer.parseInt(textField_1.getText()) > Integer.parseInt(textField_2.getText())) {
						JOptionPane.showMessageDialog(contentPane, "��������ȷ��ȡֵ��Χ", "����", JOptionPane.WARNING_MESSAGE);
					} else {
						show_wage_all_set wage_set = new show_wage_all_set();
						wage_set.min = textField_1.getText();
						wage_set.max = textField_2.getText();
						query_wage_GUI.main(null);

						// �������
						textField_1.setText(null);
						textField_2.setText(null);
					}
				} catch (Exception e2) {
					// TODO: handle exception
					textField_1.setText(null);
					textField_2.setText(null);
					JOptionPane.showMessageDialog(contentPane, "��ѯ����", "����", JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		contentPane.add(btnNewButton_3_1);

		// ��ѯָ��ְ����Ϣ
		JLabel lblNewLabel_5 = new JLabel("\u67E5\u8BE2\u6307\u5B9A\u804C\u5DE5\u4FE1\u606F:");
		lblNewLabel_5.setBounds(285, 16, 105, 15);
		lblNewLabel_5.setFocusable(true);

		contentPane.add(lblNewLabel_5);

		// �����ı���
		textField_3 = new JTextField();
		textField_3.setBounds(400, 8, 180, 30);
		textField_3.addFocusListener(new JTextFieldHintListener(textField_3, "������������ְ���Ų�ѯ"));
		contentPane.add(textField_3);
		textField_3.setColumns(10);

		// ������ť
		JButton btnNewButton_4 = new JButton("\u641C\u7D22");
		btnNewButton_4.setBounds(600, 8, 71, 30);
//		btnNewButton_4.setBackground(Color.YELLOW);
		// ��ť�������¼�
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String a = textField_3.getText();
				if (a.equals("������������ְ���Ų�ѯ")) {
					JOptionPane.showMessageDialog(contentPane, "�������ѯ���ݣ�", "����", JOptionPane.WARNING_MESSAGE);
				} else {
					try {
						if (String.valueOf(textField_3.getText()).matches("^\\d+$")) {
							query_the_worker.won_set = textField_3.getText();
							// ��ѯ��������
							query_the_worker.won_show_the_worker();
							// ��ѯ����ְ����Ϣ����
							Modify_delete_window modify_delete_window = new Modify_delete_window();
							modify_delete_window.won = query_the_worker.won;
							modify_delete_window.name = query_the_worker.name;
							modify_delete_window.sex = query_the_worker.sex;
							modify_delete_window.age = query_the_worker.age;
							modify_delete_window.education = query_the_worker.education;
							modify_delete_window.salary = query_the_worker.salary;
							modify_delete_window.address = query_the_worker.address;
							modify_delete_window.phone = query_the_worker.phone;
							modify_delete_window.hiredate = query_the_worker.hiredate;
							modify_delete_window.working_condition = query_the_worker.working_condition;
							modify_delete_window.main(null);

							// �������
							query_the_worker.won = query_the_worker.name = query_the_worker.sex = query_the_worker.age = query_the_worker.education = query_the_worker.salary = query_the_worker.address = query_the_worker.phone = query_the_worker.hiredate = query_the_worker.working_condition = null;
							textField_3.setText(null);

						} else {
							query_the_worker.name_set = textField_3.getText();
							query_the_worker.name_show_the_worker();
							// ��ѯ����ְ����Ϣ����
							Modify_delete_window modify_delete_window = new Modify_delete_window();
							modify_delete_window.won = query_the_worker.won;
							modify_delete_window.name = query_the_worker.name;
							modify_delete_window.sex = query_the_worker.sex;
							modify_delete_window.age = query_the_worker.age;
							modify_delete_window.education = query_the_worker.education;
							modify_delete_window.salary = query_the_worker.salary;
							modify_delete_window.address = query_the_worker.address;
							modify_delete_window.phone = query_the_worker.phone;
							modify_delete_window.hiredate = query_the_worker.hiredate;
							modify_delete_window.working_condition = query_the_worker.working_condition;
							modify_delete_window.main(null);

							// �������
							query_the_worker.won = query_the_worker.name = query_the_worker.sex = query_the_worker.age = query_the_worker.education = query_the_worker.salary = query_the_worker.address = query_the_worker.phone = query_the_worker.hiredate = query_the_worker.working_condition = null;
							textField_3.setText(null);
						}

					} catch (Exception e1) {
						JOptionPane.showMessageDialog(contentPane, "δ���ҵ������Ϣ�������²�ѯ��", "����",
								JOptionPane.WARNING_MESSAGE);
					}
				}

			}
		});
		contentPane.add(btnNewButton_4);

		ButtonGroup group1 = new ButtonGroup();

		// ����������ѡ��ť
		JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("\u6309\u5DE5\u8D44\u6392\u5E8F");
		rdbtnNewRadioButton_2.setBounds(741, 20, 105, 15);
		group1.add(rdbtnNewRadioButton_2);
		contentPane.add(rdbtnNewRadioButton_2);

		// ��ѧ������ѡ��ť
		JRadioButton rdbtnNewRadioButton_2_1 = new JRadioButton("\u6309\u5B66\u5386\u6392\u5E8F");
		rdbtnNewRadioButton_2_1.setBounds(841, 20, 105, 15);
		group1.add(rdbtnNewRadioButton_2_1);
		contentPane.add(rdbtnNewRadioButton_2_1);

		// ˢ�°�ť
		JButton btnNewButton_4_1 = new JButton("ˢ��");
		btnNewButton_4_1.setBounds(1000, 5, 105, 40);
//		btnNewButton_4_1.setBackground(Color.YELLOW);
		// ��ָ����Χ�Ĺ�������
		btnNewButton_4_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// �رյ�ǰ����
				dispose();
				main(null);
			}
		});
		contentPane.add(btnNewButton_4_1);

		// ��������
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(285, 55, 890, 583);
		contentPane.add(scrollPane);

		TimerTask timerTask = new TimerTask() {
			@Override
			public void run() {
				// TODO �Զ����ɵķ������

				// ����İ�ť
				if (rdbtnNewRadioButton_2.isSelected() == true) {
					user.if_rs = 1; // ������
				} else if (rdbtnNewRadioButton_2_1.isSelected() == true) {
					user.if_rs = 2; // ��ѧ��
				} else {
					user.if_rs = 0; // ��Ĭ��
				}

				table_2 = new JTable();
				table_2.setEnabled(false);
				DefaultTableCellRenderer tcr = new DefaultTableCellRenderer();// ��Ԫ����Ⱦ��
				tcr.setHorizontalAlignment(JLabel.CENTER);
				table_2.setDefaultRenderer(Object.class, tcr);// ������Ⱦ��
				table_2.setRowHeight(25);
				try {
					table_2.setModel(new DefaultTableModel(queryData(),
							new String[] { "\u5E8F\u53F7", "\u804C\u5DE5\u53F7", "\u59D3\u540D", "\u6027\u522B",
									"\u5E74\u9F84", "\u5B66\u5386", "\u5DE5\u8D44", "\u4F4F\u5740", "\u7535\u8BDD",
									"\u5165\u804C\u65F6\u95F4", "\u72B6\u6001" }));
				} catch (SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				// ��ͷ��С
				table_2.getColumnModel().getColumn(0).setPreferredWidth(40);
				table_2.getColumnModel().getColumn(2).setPreferredWidth(50);
				table_2.getColumnModel().getColumn(3).setPreferredWidth(40);
				table_2.getColumnModel().getColumn(4).setPreferredWidth(40);
				table_2.getColumnModel().getColumn(5).setPreferredWidth(40);
				table_2.getColumnModel().getColumn(6).setPreferredWidth(60);
				table_2.getColumnModel().getColumn(7).setPreferredWidth(230);
				table_2.getColumnModel().getColumn(8).setPreferredWidth(80);
				table_2.getColumnModel().getColumn(9).setPreferredWidth(80);
				table_2.getColumnModel().getColumn(10).setPreferredWidth(60);
				scrollPane.setViewportView(table_2);

			}
		};

		timer.schedule(timerTask, 0, 2000);
	}

	public Object[][] queryData() throws SQLException {
		List<show_all> list = user.show_all();
		;
		textadminObjects = new Object[list.size()][11];

		for (int i = 0; i < list.size(); i++) {
			for (int j = 0; j < textadminObjects.length; j++) {
				textadminObjects[i][0] = i + 1;
				// ְ����
				textadminObjects[i][1] = list.get(i).getwon();

				// ����
				textadminObjects[i][2] = list.get(i).getname();

				// �Ա�
				textadminObjects[i][3] = list.get(i).getsex();

				// ����
				textadminObjects[i][4] = list.get(i).getage();

				// ѧ��
				textadminObjects[i][5] = list.get(i).geteducation();

				// ����
				textadminObjects[i][6] = list.get(i).getsalary();

				// סַ
				textadminObjects[i][7] = list.get(i).getaddress();

				// �绰
				textadminObjects[i][8] = list.get(i).getphone();

				// ��ְ����
				textadminObjects[i][9] = list.get(i).gethiredate();

				// ״̬
				textadminObjects[i][10] = list.get(i).getworking_condition();
			}
		}
		return textadminObjects;
	}
}
