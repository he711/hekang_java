package main_interface_GUI;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import main_interface_backend_Query_the_worker.Modify_the_worker_backend;
import main_interface_backend_Query_the_worker.The_main_window_delete;

public class Modify_delete_window extends JFrame {

	private JPanel contentPane;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;

	public static String won; // ְ����
	public static String name; // ����
	public static String sex; // �Ա�
	public static String age; // ����
	public static String education; // ѧ��
	public static String salary; // ����
	public static String address; // סַ
	public static String phone; // �绰
	public static String hiredate; // ��ְʱ��
	public static String working_condition; // ״̬

	// ������Ļ�ȡ
	String education_get;
	String sex_get;

	// Ĭ�ϵ�������
	static int n, m;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		// ��������������ͬ��
		switch (sex) {
		case "��":
			n = 0;
			break;
		default:
			n = 1;
			break;
		}

		// ��������������ͬ��
		switch (education) {
		case "�о���":
			m = 0;
			break;
		case "����  ":
			m = 1;
			break;
		case "ר��  ":
			m = 2;
			break;
		case "��ר  ":
			m = 3;
			break;
		case "����  ":
			m = 4;
			break;
		case "����  ":
			m = 5;
			break;
		case "Сѧ  ":
			m = 6;
			break;
		default:
			m = 7;
			break;
		}

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Modify_delete_window frame = new Modify_delete_window();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Modify_delete_window() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		// ְ����
		JLabel lblNewLabel_2_1_1_1_1 = new JLabel("\u804C\u5DE5\u53F7:");
		lblNewLabel_2_1_1_1_1.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2_1_1_1_1.setBounds(202, 111, 71, 26);
		contentPane.add(lblNewLabel_2_1_1_1_1);

		// ����
		JLabel lblNewLabel_2 = new JLabel("\u59D3\u540D:");
		lblNewLabel_2.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2.setBounds(202, 162, 58, 26);
		contentPane.add(lblNewLabel_2);

		// �Ա�
		JLabel lblNewLabel_2_2 = new JLabel("\u6027\u522B:");
		lblNewLabel_2_2.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2_2.setBounds(202, 223, 58, 23);
		contentPane.add(lblNewLabel_2_2);

		// ����
		JLabel lblNewLabel_2_3 = new JLabel("\u5E74\u9F84:");
		lblNewLabel_2_3.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2_3.setBounds(202, 278, 58, 26);
		contentPane.add(lblNewLabel_2_3);

		// ѧ��
		JLabel lblNewLabel_2_1 = new JLabel("\u5B66\u5386:");
		lblNewLabel_2_1.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2_1.setBounds(202, 343, 58, 23);
		contentPane.add(lblNewLabel_2_1);

		// ����
		JLabel lblNewLabel_2_1_2 = new JLabel("\u5DE5\u8D44:");
		lblNewLabel_2_1_2.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2_1_2.setBounds(509, 223, 58, 23);
		contentPane.add(lblNewLabel_2_1_2);

		// ��ַ
		JLabel lblNewLabel_2_1_1 = new JLabel("\u5730\u5740:");
		lblNewLabel_2_1_1.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2_1_1.setBounds(509, 164, 58, 23);
		contentPane.add(lblNewLabel_2_1_1);

		// �绰
		JLabel lblNewLabel_2_1_3 = new JLabel("\u7535\u8BDD:");
		lblNewLabel_2_1_3.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2_1_3.setBounds(509, 280, 58, 23);
		contentPane.add(lblNewLabel_2_1_3);

		// ��ְʱ��
		JLabel lblNewLabel_2_1_3_1 = new JLabel("\u5165\u804C\u65F6\u95F4:");
		lblNewLabel_2_1_3_1.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2_1_3_1.setBounds(507, 111, 104, 26);
		contentPane.add(lblNewLabel_2_1_3_1);

		// ״̬
		JLabel lblNewLabel_2_1_1_1 = new JLabel("\u72B6\u6001:");
		lblNewLabel_2_1_1_1.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2_1_1_1.setBounds(509, 343, 58, 23);
		contentPane.add(lblNewLabel_2_1_1_1);

		// ȡ����ť
		JButton btnNewButton_1 = new JButton("\u53D6\u6D88");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnNewButton_1.setFont(new Font("����", Font.PLAIN, 14));
		btnNewButton_1.setBounds(602, 424, 97, 36);
		contentPane.add(btnNewButton_1);

		// ɾ����ť
		JButton btnNewButton = new JButton("\u5220\u9664");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				The_main_window_delete the_main_window_delete = new The_main_window_delete();
				try {
					the_main_window_delete.Remove_the_worker_name(name);
					JOptionPane.showMessageDialog(contentPane, "ɾ���ɹ���", "�ɹ�", JOptionPane.WARNING_MESSAGE);
					dispose();

				} catch (SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					JOptionPane.showMessageDialog(contentPane, "ɾ��ʧ�ܣ�", "����", JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 14));
		btnNewButton.setBounds(279, 424, 97, 36);
		contentPane.add(btnNewButton);

		// �޸İ�ť
		JButton btnNewButton_2 = new JButton("\u4FEE\u6539");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Modify_the_worker_backend modify_delete_window = new Modify_the_worker_backend();
				modify_delete_window.won = won;
				modify_delete_window.name = textField_1.getText();
				modify_delete_window.age = textField_2.getText();
				modify_delete_window.salary = textField_3.getText();
				modify_delete_window.address = textField_4.getText();
				modify_delete_window.phone = textField_5.getText();
				modify_delete_window.hiredate = textField_6.getText();
				modify_delete_window.working_condition = textField_7.getText();
				modify_delete_window.sex = sex_get;
				modify_delete_window.education = education_get;
				try {
					modify_delete_window.modify_the_worker_won();
					JOptionPane.showMessageDialog(contentPane, "�޸ĳɹ���", "�ɹ�", JOptionPane.WARNING_MESSAGE);
				} catch (SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					JOptionPane.showMessageDialog(contentPane, "�޸�ʧ�ܣ�", "����", JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton_2.setFont(new Font("����", Font.PLAIN, 14));
		btnNewButton_2.setBounds(439, 424, 97, 36);
		contentPane.add(btnNewButton_2);

		// �����
		JLabel lblNewLabel = new JLabel("\u804C\u5DE5\u4FE1\u606F");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.DARK_GRAY);
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setFont(new Font("΢���ź�", Font.BOLD, 40));
		lblNewLabel.setBounds(343, 10, 254, 64);
		contentPane.add(lblNewLabel);

		// ְ�����ı�
		JLabel lblNewLabel_1 = new JLabel(won);
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(279, 111, 97, 26);
		contentPane.add(lblNewLabel_1);

		// �����ı���
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(266, 164, 97, 26);
		textField_1.setText(name);
		contentPane.add(textField_1);

		// �����ı���
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(266, 280, 97, 26);
		textField_2.setText(age);
		contentPane.add(textField_2);

		// �����ı���
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(577, 223, 97, 26);
		textField_3.setText(salary);
		contentPane.add(textField_3);

		// ��ַ�ı���
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(577, 164, 344, 26);
		textField_4.setText(address);
		contentPane.add(textField_4);

		// �绰�ı���
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(577, 280, 97, 26);
		textField_5.setText(phone);
		contentPane.add(textField_5);

		// ��ְʱ���ı���
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(610, 113, 160, 26);
		textField_6.setText(hiredate);
		contentPane.add(textField_6);

		// ״̬�ı���
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(577, 343, 97, 26);
		textField_7.setText(working_condition);
		contentPane.add(textField_7);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBounds(257, 343, 119, 32);
		contentPane.add(panel);

		// ѧ��������
		JComboBox comboBox = new JComboBox();
		comboBox.addItem("�о���");
		comboBox.addItem("����");
		comboBox.addItem("ר��");
		comboBox.addItem("��ר");
		comboBox.addItem("����");
		comboBox.addItem("����");
		comboBox.addItem("Сѧ");
		comboBox.addItem("��");
		comboBox.setBounds(10, 0, 99, 23);
		panel.add(comboBox);
		// Ĭ�ϵ�ѧ��
		comboBox.setSelectedIndex(m);
		// ��ȡĬ��������ѡ��
		education_get = comboBox.getSelectedItem().toString();

		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// ���»�ȡ������ѡ��
				education_get = comboBox.getSelectedItem().toString();
			}
		});

		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBounds(257, 223, 119, 32);
		contentPane.add(panel_1);

		// �Ա�������
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.addItem("��");
		comboBox_1.addItem("Ů");
		comboBox_1.setBounds(10, 0, 99, 23);
		panel_1.add(comboBox_1);
		// Ĭ�ϵ��Ա�
		comboBox_1.setSelectedIndex(n);
		// ��ȡĬ��������ѡ��
		sex_get = comboBox_1.getSelectedItem().toString();

		comboBox_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// ���»�ȡ������ѡ��
				sex_get = comboBox_1.getSelectedItem().toString();
			}
		});

	}
}
