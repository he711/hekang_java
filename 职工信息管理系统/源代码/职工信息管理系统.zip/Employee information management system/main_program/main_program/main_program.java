package main_program;

import login_GUI.LoginUI;

//�����￪ʼ
public class main_program {
	public static void main(String[] args) {
		new LoginUI();
		LoginUI.main(null);
	}
}
